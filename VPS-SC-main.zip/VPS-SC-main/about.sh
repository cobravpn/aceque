#!/bin/bash

clear
echo ""
echo -e "\e[94m ============================================================ "  |lolcat
echo -e "\e[94m ============================================================ "  |lolcat
echo -e "          █████╗ ██████╗  █████╗ ███╗   ███╗  " |lolcat
echo -e "         ██╔══██╗██╔══██╗██╔══██╗████╗ ████║  " |lolcat
echo -e "         ███████║██║  ██║███████║██╔████╔██║  " |lolcat
echo -e "         ██╔══██║██║  ██║██╔══██║██║╚██╔╝██║  " |lolcat
echo -e "         ██║  ██║██████╔╝██║  ██║██║ ╚═╝ ██║  " |lolcat
echo -e "         ╚═╝  ╚═╝╚═════╝ ╚═╝  ╚═╝╚═╝     ╚═╝  " |lolcat
echo ""
echo -e "\e[0m   ║ For Debian 9 & Debian 10 64 bit                   ║ "
echo -e "\e[0m   ║ For Ubuntu 18.04 & Ubuntu 20.04 64 bit            ║ "
echo -e "\e[0m   ║ For VPS with KVM and VMWare virtualization        ║ "
echo -e "\e[0m   ║ Build Up By Dragon0193                            ║ "
echo -e "\e[0m   ║ Thank you Allah for Everything                    ║ "
echo -e "\e[94m ============================================================ " |lolcat
echo -e "\e[94m ============================================================ " |lolcat
echo ""
